/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */


package com.crp.whirl;

import java.util.Arrays;
import java.util.List;

public class Wheel extends MachinePart {
	private int hand = 0;
	private int direction = 1;

	private List<Command> commands;

	public int value = 0;

	public Wheel(Command... commands) { 
		this.commands = Arrays.asList(commands);
	}

	public final void execute() {
		commands.get(hand).execute(machine);
		machine.flip();
	}

	public final void advance() {
		hand += direction;

		if (hand < 0) hand = size() - 1;
		else if (hand == size()) hand = 0;

		assert 0 <= hand && hand < size();
	}

	public final void flip() { direction = -direction; }

	public final int distanceTo(Command query) {
		assert commands.contains(query);
		
		// get the offset, which might be negative
		int offset = (commands.indexOf(query) - hand) * direction;
		
		if (offset < 0) { 
			// if the offset is negative, substract it
			// from the size of the array. 
			// since the offset IS negative, it is in
			// fact added to the array's size.
			offset = size() + offset;
		}

		return offset;
	}

	public final boolean contains(Command query) {
		return commands.contains(query);	
	}

	public final int size() {
		return commands.size();
	}
}
