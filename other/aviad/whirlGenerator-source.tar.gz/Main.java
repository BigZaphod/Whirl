/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */


package com.crp.whirl;

public class Main {

public static void main(String... args) {
	
	if (args.length == 0) error();
	
	Machine machine = MachineFactory.create();

	Assembler asm = new Assembler(machine, System.out);

	if ("calc".equals(args[0])) {
		if (args.length < 4) error();

		int a = Integer.valueOf(args[2]);
		int b = Integer.valueOf(args[3]);
		Calculator calc = new Calculator(asm);

		if ("add".equals(args[1])) calc.add(a, b);
		else if ("sub".equals(args[1])) calc.sub(a, b);
		else if ("mul".equals(args[1])) calc.mul(a, b);
		else if ("div".equals(args[1])) calc.div(a, b);
		else error();

		// now print the value
		asm.execute(LogicCommand.One);
		asm.execute(MathCommand.Store);
		asm.execute(LogicCommand.IntIO);
	} else if ("print".equals(args[0])) {
		if (args.length < 2) error();

		new Printer(asm).print(args[1]);
	} else error();

	System.out.println();
}

private static void error() {
	System.err.println("Syntax: ");
	System.err.println("\tcalc [add|sub|mul|div] [a] [b]");
	System.err.println("\tprint [string]");
	System.exit(-1);
}

public static void fib(int f) { }
}

