/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.crp.whirl;

public final class Calculator {
	private Assembler asm;

	public Calculator(Assembler asm) {
		this.asm = asm;
	}

	public void add(int a, int b) {
		asm.value(a);
		asm.execute(MathCommand.Store);
		
		asm.value(b);
		asm.execute(MathCommand.Add);
	}

	public void sub(int a, int b) {
		add(a, -b);
	}

	public void mul(int a, int b) {
		asm.value(a);
		asm.execute(MathCommand.Store);
	
		asm.value(b);
		asm.execute(MathCommand.Mult);
	}

	public void div(int a, int b) {
		asm.value(b);
		asm.execute(MathCommand.Store);
		
		asm.value(a);
		asm.execute(MathCommand.Div);
	}

	public void fib(int offset1, int offset2) {
	}
}
