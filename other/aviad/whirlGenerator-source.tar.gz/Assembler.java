/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */


package com.crp.whirl;

import java.io.PrintStream;
import java.io.OutputStream;

public final class Assembler {
	private Machine machine;
	private PrintStream out;

	public Assembler(Machine machine, OutputStream out) {
		this.machine = machine;

		if (out instanceof PrintStream) {
			this.out = (PrintStream)out;
		} else {
			this.out = new PrintStream(out);
		}
	}

	public void execute(Command command) {
		// ensure this is the correct wheel
		if (!machine.wheel().contains(command)) {
			noop();
		}

		// if its faster to go the other way, flip
		// the wheel's direction
		int distance = machine.wheel().distanceTo(command);
		if (distance > (machine.wheel().size() / 2)) {
			out.print('0');
			machine.wheel().flip();
			distance = machine.wheel().distanceTo(command);
		}

		// advance the wheel until it reaches the
		// desired command
		while (distance-- > 0) {
			out.print('1');
			machine.wheel().advance();
		}

		// and execute
		out.print("00");
		machine.wheel().execute();
	}

	public void noop() {
		// execute the correct Noop command
		// according to the current wheel.
		if (machine.wheel() == machine.logicWheel) {
			execute(LogicCommand.Noop);
		} else { // machine.wheel() == machine.mathWheel
			execute(MathCommand.Noop);
		}
	}

	public void ensure(Wheel wheel) {
		if (machine.wheel() != wheel) noop();
	}

	// sets the value in the math wheel to 
	// the given value	
	public void value(final int val) {
		final int prodiff = 10;

		if (machine.mathWheel.value == val) {
			return ;
		}
		
		if (val == 0) {
			value0();
			logicMinusOne();
			return ;
		}

		if (val == 1) {
			value1();
			logicMinusOne();

			return ;
		}

		if (val == -1) {
			valueM1();

			// apply -1 to logic
			if (machine.logicWheel.value != 1) {
				execute(LogicCommand.One); // logic = 1
			}
			execute(LogicCommand.DAdd); // ptr++
			execute(MathCommand.Store); // [1] <- -1
			execute(LogicCommand.Load); // logic = -1
			execute(LogicCommand.DAdd); // ptr--

			return ;
		}

		if (machine.mathWheel.value == -val) {
			execute(MathCommand.Neg);
			logicMinusOne();

			return ;
		}


		int absval = (int)Math.abs(val);

		if (absval * 2 > prodiff && 
				-prodiff < (absval - machine.mathWheel.value) && 
				(absval - machine.mathWheel.value) < prodiff) {
			// if difference is profitable to use instead of re-calc
			execute(LogicCommand.One); // logic = 1
			execute(LogicCommand.DAdd); // ptr++
			execute(MathCommand.Store); // [1] <- math 
			value(absval - machine.mathWheel.value); // math = val - math, logic = -1
			execute(MathCommand.Add); // math = math + [1] (val - math + math)
			execute(LogicCommand.DAdd); // ptr--
		} else {
			int sqrt = (int)Math.ceil(Math.sqrt(absval));

			if (absval - sqrt < 30) {
				valueByAdd(absval);
			} else { // gd > 1
				valueByMul(absval, sqrt);
			}
		}
		
		// apply negative mark if needed
		if (val < 0) {
			execute(MathCommand.Neg);
		}
	}
	
	private void value0() {
		if (machine.mathWheel.value != 0) {
			execute(MathCommand.Zero);
		}
	}

	private void value1() {
		if (machine.mathWheel.value != 1) {
			value0();
			execute(MathCommand.Not);
		}
	}

	private void valueM1() {
		if (machine.mathWheel.value != -1) {
			value1();
			execute(MathCommand.Neg);
		}
	}

	public void logicMinusOne() {
		if (machine.logicWheel.value != -1) {
			if (machine.logicWheel.value != 1) {
				execute(LogicCommand.One); // logic = 1
			}

			execute(LogicCommand.DAdd); // ptr++
			if (machine.memory.get() != machine.mathWheel.value) {
				execute(MathCommand.Store); // [1] <- math
			}

			value(-1); // math = -1, logic = -1

			execute(MathCommand.Load); // math <- [1]
			execute(LogicCommand.DAdd); // ptr--
		}
	}

	private void valueByAdd(int val) { 
		prepare(); // math = 0, logic = -1, [1] = 1, [2] = -1, ptr -> [1]

		if (machine.mathWheel.value != 1) {
			execute(MathCommand.Load);  // math <- [1] (1)
		}

		int inc = 1;
		
		while (val-- > 1) {
			execute(MathCommand.Add); // math <- math + *[1] (1)
		}

		execute(LogicCommand.DAdd); // ptr--
	}

	private void valueByMul(int val, int div) { 
		int res = val / div;
		int mod = val % div;
		prepare(); // math = 0, logic = -1, [1] = 1, [2] = -1, ptr => 1
		value(res); // math <- res, logic = -1, [1] = 1, [2] = 1, [3] = -1, ptr => 1
		execute(MathCommand.Store); // [1] <- math (res)
		value(div); // math <- div, logic = -1, [1] = res, [2] = 1, [3] = -1, ptr => 1
		execute(MathCommand.Mult); // math <- math (div) * *[1] (res)
		execute(MathCommand.Store); // [1] <- math (div * res)
		value(mod); // math <- mod, logic = -1, [1] = div * res, [2] = 1, [3] = -1, ptr => 1
		execute(MathCommand.Add); // math <- math (mod) + *[1] (res * div)
		execute(LogicCommand.DAdd); // ptr--, ptr => 0
	}

	// final state: math = -1, logic = -1, [1] = 1, [2] = -1, ptr = 1
	private void prepare() {
		execute(MathCommand.Zero); // math = 0
		execute(LogicCommand.One); // logic = 1
		execute(MathCommand.Not); // math = 1
		execute(LogicCommand.DAdd); // ptr++

		if (machine.memory.get() != 1) {
			execute(MathCommand.Store); // [1] <- math (1)
		}

		execute(LogicCommand.DAdd); // ptr++

		if (machine.memory.get() != -1) {
			execute(MathCommand.Neg);   // math = -1
			execute(MathCommand.Store); // [2] <- math (-1)
		}

		execute(LogicCommand.Load); // logic <- [2] (-1)
		execute(LogicCommand.DAdd); // ptr--
	}
		
}
