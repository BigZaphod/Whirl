/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.crp.whirl;

public enum LogicCommand implements Command {
	Noop { public void execute(Machine machine) { } },
	Exit { public void execute(Machine machine) { System.exit(0); } },
	One  { public void execute(Machine machine) { machine.logicWheel.value = 1; } },
	Zero { public void execute(Machine machine) { machine.logicWheel.value = 0; } },
	Load { public void execute(Machine machine) { machine.logicWheel.value = machine.memory.get(); } },
	Store { public void execute(Machine machine) { machine.memory.set(machine.logicWheel.value); } },
	PAdd { public void execute(Machine machine) { } },
	DAdd { public void execute(Machine machine) { machine.memory.move(machine.logicWheel.value); } },
	Logic { 
		public void execute(Machine machine) { 
			machine.logicWheel.value = machine.memory.get() == 0 ? 0 : machine.logicWheel.value & 1;
		}
	},
	If { public void execute(Machine machine) { } },
	IntIO { 
		public void execute(Machine machine) {
			if (machine.logicWheel.value == 0) {
				machine.memory.set(machine.io.readInt());
			} else { // value != 0
				machine.io.writeInt(machine.memory.get());
			}
		}
	},
	AscIO {
		public void execute(Machine machine) {
			if (machine.logicWheel.value == 0) {
				machine.memory.set(machine.io.readChar());
			} else { // value != 0
				machine.io.writeChar((char)machine.memory.get());
			}
		}
	};

	public abstract void execute(Machine machine);
}
		
