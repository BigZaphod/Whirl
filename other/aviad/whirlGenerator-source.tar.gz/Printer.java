/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */


package com.crp.whirl;

public final class Printer {

	Assembler asm;

	public Printer(Assembler asm) {
		this.asm = asm;
	}
	
	public void print(String text) {
		long total = 0;
		byte[] bytes = text.getBytes();
		
		for (byte b : bytes) {
			total += b;
		}

		byte avg = (byte)(total / text.length());
		
		asm.value(avg);
		asm.execute(LogicCommand.One);
		
		// fills the memory with average sized bytes
		for (byte b : bytes) {
			asm.execute(MathCommand.Store);
			asm.execute(LogicCommand.DAdd);
		}

		asm.value(-1); 		        // math = -1
		asm.execute(MathCommand.Store); // [length + 1] <- -1 
		asm.execute(LogicCommand.Load); // logic = -1
		
		for (byte b : bytes) {
			asm.execute(LogicCommand.DAdd); // ptr--
			asm.value(b - avg); // math = b - avg, logic = -1, trashing ptr+
			asm.execute(MathCommand.Add); 
			asm.execute(MathCommand.Store);
			asm.execute(LogicCommand.AscIO);
		}
	}

	public void printd(String text) {
		for (byte b : text.getBytes()) {
			asm.value(b);
			asm.execute(MathCommand.Store);
			asm.execute(LogicCommand.AscIO);
		}	
	}
}
