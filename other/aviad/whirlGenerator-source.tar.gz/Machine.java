/**
 *  Copyright 2005-2006 Aviad Ben Dov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.crp.whirl;

public final class Machine {
	public final Wheel logicWheel;
	public final Wheel mathWheel;

	public final IO io;
	public final Memory memory;

	private boolean isLogic;

	public Machine(Wheel logicWheel, Wheel mathWheel, boolean isLogic) {
		this.memory = new Memory();
		this.io = new IO();
		this.mathWheel = mathWheel;
		this.logicWheel = logicWheel;
		this.isLogic = isLogic;

		mathWheel.machine = this;
		logicWheel.machine = this;
		io.machine = this;
		memory.machine = this;
	}

	public Wheel wheel() {
		return isLogic ? logicWheel : mathWheel;
	}

	public void flip() {
		isLogic = !isLogic;
	}
}

